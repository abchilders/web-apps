/*
   Alex Childers
   Last modified: 2019/01/25
*/

spool 	328lab1-out.txt

prompt 	Alex Childers

select	*
from	dept;

spool off
