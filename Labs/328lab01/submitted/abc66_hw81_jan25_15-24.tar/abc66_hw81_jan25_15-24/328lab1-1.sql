/*
   Alex Childers
   01/25/2019
*/

spool 	328lab1-out.txt

prompt 	Alex Childers

select	*
from	dept;

spool off
