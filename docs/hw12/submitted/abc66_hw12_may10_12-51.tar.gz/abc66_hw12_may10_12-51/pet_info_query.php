<?php
    session_start();

/* 	Alex Childers
	Last modified: 2019/05/10
*/

/*	Builds an XML document based on the pet value in $_GET["choice"]
	Requires: hsu_conn_sess.php 
*/

?>
<?xml version="1.0" encoding="utf-8" ?>
<?php
    require_once("hsu_conn_sess.php");
?>

<pet_result>
<?php
    $conn = hsu_conn_sess($_SESSION["username"], $_SESSION["password"]);

    $userChoice = strip_tags($_GET["choice"]);
	
	$query_string = "select *
					 from 	pet
					 where	pet_id = :chosen_id"; 

    $query_stmt = oci_parse($conn, $query_string);
	oci_bind_by_name($query_stmt, ":chosen_id", $userChoice); 
    oci_execute($query_stmt, OCI_DEFAULT);
	
	// should only return one row since pet IDs are unique 
	oci_fetch($query_stmt); 
	$pet_id = oci_result($query_stmt, "PET_ID"); 
	$pet_name = oci_result($query_stmt, "PET_NAME"); 
	$pet_sex = oci_result($query_stmt, "SEX"); 
	$spayed_neutered = oci_result($query_stmt, "IS_SPAYED_NEUTERED"); 
	$birthday = oci_result($query_stmt, "BIRTHDAY"); 
	$pet_type = oci_result($query_stmt, "PET_TYPE"); 
	$owner_id = oci_result($query_stmt, "OWNER_ID"); 
?>
	<label for="name" id="name_label" class="option_label"> Name: </label>
	<input type="text" id="name" name="name" placeholder="<?= $pet_name ?>" />
	<br /> 
	
	<fieldset id="sex">
		<legend> Sex </legend>
		
		<input type="radio" name="sex" value="f" id="f" 
		<?php
			if($pet_sex === "f")
			{
				?>
				checked="checked"
				<?php
			}
		?>
		/>
		<label for="f"> Female </label>
		
		<input type="radio" name="sex" value="m" id="m" 
		<?php
			if($pet_sex === "m")
			{
				?>
				checked="checked"
				<?php
			}
		?>
		/>
		<label for="m"> Male </label>
	</fieldset>
	
	<fieldset id="fixed">
		<legend> Are they spayed/neutered? </legend> 
		
		<input type="radio" name="fixed" value="y" id="y"
		<?php
			if($spayed_neutered === "y")
			{
				?>
				checked="checked"
				<?php
			}
		?>
		/>
		<label for="y"> Yes </label> 
		
		<input type="radio" name="fixed" value="n" id="n"
		<?php
			if($spayed_neutered === "n")
			{
				?>
				checked="checked"
				<?php
			}
		?>
		/>
		<label for="n"> No </label>
	</fieldset>
	
	<fieldset id="pet_type">
		<legend> Species </legend>
		<input type="radio" name="pet_type" value="dog" id="dog"
		<?php
			if($pet_type === "dog")
			{
				?>
				checked="checked"
				<?php
			}
		?>
		/>
		<label for="dog"> Dog </label> 
		
		<input type="radio" name="fixed" value="cat" id="cat"
		<?php
			if($pet_type === "cat")
			{
				?>
				checked="checked"
				<?php
			}
		?>
		/>
		<label for="cat"> Cat </label>
	</fieldset>
<?php
    oci_free_statement($query_stmt);
    oci_close($conn);
?>
</pet_result>