/* CS 328 - HW 1 - Problem 3
   Alex Childers
   Last modified: 2019/01/30
*/

spool bks-try-out.txt

prompt by Alex Childers

prompt =================
prompt Problem 3 part a
prompt =================

/* Project the names of publishers and which state they're in, displayed in
   alphabetical order of publisher name. Add a statement before this query
   specifying that the state should be displayed in a column of width 9. */

column pub_state format a9

select 		pub_name, pub_state
from 		publisher
order by	pub_name; 

prompt =================
prompt Problem 3 part b
prompt =================

column title_price format $999.99

select 		title_price, title_name
from 		title
where		pub_id = (select pub_id
		  	  from 	 publisher
		  	  where  pub_name = 'Benjamin/Cummings')
order by 	title_price desc; 

prompt =================
prompt Problem 3 part c
prompt =================

column "AVG PRICE" format $999.99

select		pub_name, count(*) "# TITLES", avg(title_price) "AVG PRICE"
from		publisher join title 
			on publisher.pub_id = title.pub_id
group by	pub_name
order by 	avg(title_price);

prompt =================
prompt Problem 3 part d
prompt =================

prompt =================
prompt Problem 3 part e
prompt =================

spool off

clear columns
