/*	Alex Childers
	CS 328 - Homework 4
	Last modified: 2019/02/23
*/

set serveroutput on

spool 328hw4-out.txt

prompt =============
prompt Alex Childers
prompt =============
prompt
prompt =========
prompt problem 6
prompt =========

/* 	Procedure: insert_order_needed

	Purpose: Expects a desired ISBN and order quantity for the desired order.
		Inserts a new row into order_needed using a key returned by function
		next_ord_needed_id, the parameter ISBN, the parameter order quantity,
		and the current date.
*/

create or replace procedure insert_order_needed(
	needed_isbn order_needed.isbn%type, 
	needed_order_qty order_needed.order_qty%type) as
	new_id order_needed.ord_needed_id%type;
begin
	-- get a new key for the next row in order_needed
	new_id := next_ord_needed_id; 
	
	-- insert a new row into order_needed with the given info
	insert into order_needed(ord_needed_id, isbn, order_qty, date_created)
	values
	(new_id, needed_isbn, needed_order_qty, sysdate); 
end; 
/
show errors

-- test the insert_order_needed procedure
start insert_order_needed_test.sql

spool off
