/* Alex Childers
   Last modified: 2019/02/06
*/

/* Function: bool_to_string: boolean -> varchar2
   Purpose: Expects a boolean value. Returns 'TRUE' if this Boolean value is true,
   	and returns 'FALSE' otherwise.
*/

create or replace function bool_to_string(bool_val boolean)
	return varchar2 as
begin
	if bool_val then
		return 'TRUE'; 
	else
		return 'FALSE';
	end if; 
end; 
/ 
show errors
