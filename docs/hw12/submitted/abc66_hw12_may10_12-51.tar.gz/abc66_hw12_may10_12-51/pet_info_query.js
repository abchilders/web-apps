"use strict"; 

// Alex Childers
// Last modified: 2019/05/10
// Creates a form based on the pet selected from a dropdown. 

window.onload = function()
	{
		// get the dropdown of pets 
		var petChoiceMenu = document.getElementById("pets"); 
		
		// attach an onchange attribute with an event handler to this dropdown 
		petChoiceMenu.onchange = makeForm; 
	};
	
// function: makeForm
// expects nothing, returns nothing. requests info to make a form based 
// 	on the user's pet choice

function makeForm()
{
	// which pet has been chosen? 
	var petChoiceMenu = document.getElementById("pets"); 
	
	var userChoice = petChoiceMenu.value; 
	
	// make and add a form 
	var choiceFieldset = document.getElementById("dynamic-dropdown"); 
	
	var choiceForm = document.getElementById("pet_info_form"); 
	var choiceLegend = document.getElementById("choice-legend"); 
	
	// if form currently exists, remove it and its legend 
	if(choiceForm)
	{
		choiceFieldset.removeChild(choiceForm); 
	}
	
	if(choiceLegend)
	{
		choiceFieldset.removeChild(choiceLegend); 
	}
	
	// now create form for current choice 
	choiceForm = document.createElement("FORM"); 
	choiceForm.id = "pet_form"; 
	choiceForm.name = "pet_form"; 
	choiceForm.method = "POST"; 
	choiceForm.action = "<?= htmlentities($_SERVER['PHP_SELF'], "
		+ "ENT_QUOTES) ?>";
		
	choiceLegend = document.createElement("legend"); 
	choiceLegend.id = "choice-legend"; 
	choiceLegend.innerHTML = "Update info for pet #" + userChoice; 
	
	choiceFieldset.appendChild(choiceLegend); 
	
	// now request form contents via Ajax 
	var ajax = new XMLHttpRequest();
	ajax.responseType = "document"; 
	ajax.overrideMimeType("text/xml"); 
	
	ajax.onreadystatechange = function()
		{
			if (ajax.readyState == 4)
			{
				if (ajax.status == 200)
				{
					// request sends back query results within 
					// various input elements -- get their contents 
					// and build input fields 
					var nameLabel = ajax.responseXM.getElementById("name_label"); 
					
				}
			}
		}
}