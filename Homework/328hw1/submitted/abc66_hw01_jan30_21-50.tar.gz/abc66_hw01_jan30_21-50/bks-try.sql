/* CS 328 - HW 1 - Problem 3
   Alex Childers
   Last modified: 2019/01/30
*/

spool bks-try-out.txt

prompt by Alex Childers

prompt =================
prompt Problem 3 part a
prompt =================

prompt =================
prompt Problem 3 part b
prompt =================

prompt =================
prompt Problem 3 part c
prompt =================

prompt =================
prompt Problem 3 part d
prompt =================

prompt =================
prompt Problem 3 part e
prompt =================

spool off
