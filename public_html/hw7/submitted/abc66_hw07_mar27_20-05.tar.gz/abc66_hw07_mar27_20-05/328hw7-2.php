<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<!--
    by: Alex Childers
    last modified: 2019/03/27

    you can run this using the URL: 
	http://nrs-projects.humboldt.edu/~abc66/cs328/hw7/328hw7-2.php

-->

<head>
    <title> HW 7-2 </title>
    <meta charset="utf-8" />

    <link href="http://nrs-projects.humboldt.edu/~abc66/normalize.css"
          type="text/css" rel="stylesheet" />
</head>

<body>

	<h1> Homework 7 Problem 2 </h1>
	
	<h2> Alex Childers </h2> 
	

    <hr />

    <p>
        Validate by pasting .xhtml copy's URL into<br />
        <a href="https://html5.validator.nu/">
            https://html5.validator.nu/
        </a>
    </p>

    <p>
        <a href=
           "http://jigsaw.w3.org/css-validator/check/referer?profile=css3">
            <img src="http://jigsaw.w3.org/css-validator/images/vcss"
                 alt="Valid CSS3!" height="31" width="88" />
        </a>
    </p>

</body>
</html>

