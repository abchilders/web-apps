/* Alex Childers
   Last modified: 2019/04/28
*/

insert into publisher
values
(300, 'George Newnes', 'London', 'UK', 200, 0.02);

insert into title
values
('0486474917', 300, 'The Adventures of Sherlock Holmes', 'Arthur Conan Doyle',
 5.00, 6.00, 10, 4, 20, 'F'); 
