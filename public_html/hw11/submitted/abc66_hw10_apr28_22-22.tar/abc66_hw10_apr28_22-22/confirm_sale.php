<?php
/*	Alex Childers
	Last modified: 2019/04/28
*/

/* 	Function: confirm_sale()
	
	Purpose: Expects the $_POST array to contain a valid ISBN and quantity, 
		returns nothing. Displays the chosen ISBN's publisher name, title, 
		author, price, entered quantity, subtotal for this quantity, computed
		tax for this quantity, and computed total for this quantity 
		including tax. Allows the user to proceed with or cancel the sale. 
		
	CURRENTLY STILL A STUB.
	TO DO: allow the user to proceed with or cancel the sale at this point
	(if they cancel, should they be logged out or only allowed to input 
	another ISBN? maybe provide a "log out" button on stage 2? 
	
	Also, gotta validate that input. $$$
*/

function confirm_sale()
{
	?>
	<p> State 3: confirm_sale() -- display sale information in order to 
		confirm. </p> 
	<?php
}
?>