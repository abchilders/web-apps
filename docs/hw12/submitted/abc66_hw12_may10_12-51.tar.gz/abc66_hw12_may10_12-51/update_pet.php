<?php
/* 	Alex Childers
	Last modified: 2019/05/10
*/

/* 	Function: update_pet 

	Purpose: Expects a valid username and password to exist in the $_SESSION
		array. Creates a form showing inputs for pet information.
*/

function update_pet()
{
	// try connecting to Oracle 
	$conn = hsu_conn_sess($_SESSION["username"], $_SESSION["password"]);
	
	?>
	<form method="post"
		  action=
		"<?= htmlentities($_SERVER['PHP_SELF'], ENT_QUOTES) ?>"
		  id="choice-form" >
		<fieldset id="choice-dropdown">
			<legend> Select a pet to update: </legend>   
			<label for="pets"> Pet </label>
			<select id="pets" name="pets">
			<?php
			// query pet info
			$pet_query_str = "select 	pet_id, pet_name
							  from		pet
							  order by 	pet_name";
			$pet_query = oci_parse($conn, $pet_query_str); 
			oci_execute($pet_query); 

			while(oci_fetch($pet_query))
			{
				$curr_id = oci_result($pet_query, "PET_ID");

				$curr_name = oci_result($pet_query, "PET_NAME"); 
				?>
				<option value="<?= $curr_id ?>">
					<?= $curr_name ?> (ID #<?= $curr_id ?>) 
				</option>
				<?php
			}
			oci_free_statement($pet_query);
			oci_close($conn); 
			?>
			</select>
		</fieldset>

		<fieldset id="dynamic-dropdown">
			<legend> Update information </legend> 
		</fieldset>

		<div class="sub_button">
			<input type="submit" name="see_menu" value="Back to menu" /> 
			<input type="submit" name="update" value="Update pet" />
		</div>
	</form>
    <?php
}

?>